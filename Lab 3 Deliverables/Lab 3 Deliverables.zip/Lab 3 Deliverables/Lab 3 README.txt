Lab 3 deliverables (Team WomenInTech)

1) Design Model
- Class Diagram
- Dialog Map
- Sequence Diagrams (both VPP and PDF)

2) Use case Model
- Use case Description
- Use case Diagram for Workout Planner
- Use case Diagram for Gym Buddy Functionality

3) System Architecture Diagram - WITFIT System Architecture Diagram

4) Application skeleton: https://github.com/suenalaba/womenintech/tree/develop
*Note the file size is extremely huge, hence we did not download it.
How to run the app: 
1) Clone the branch 'develop' into your local branch
2) Change directory to the folder in your local branch and run 'code .'
3) Run 'npm install -g @ionic/cli'
4) Run 'npm i'
5) Run 'ionic serve'
6) App will run in localhost(web browser)